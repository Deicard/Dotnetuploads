using System;

namespace BusinessLogic.Algorithms {
    interface IAlgo{
        string generate(String password);
    }
}