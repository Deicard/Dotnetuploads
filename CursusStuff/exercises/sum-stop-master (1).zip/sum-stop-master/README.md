# Lab Sum

This lab will teach you how to use a console app with ReadLine and how to  parse text to numbers.

For this exercise you will **not** create the exercise from scratch. Instead you will update this given repository.

## Exercise

The user can enter numbers until they type "stop".  When that happens, the program stop asking for new numbers and the sum of the  numbers is displayed.

### When done:
Upload the created library to gitlab in your student-name folder.


# Hints and Tricks
  - Use the C# cheat sheet on gitlab.
  - Use the dotnet cli cheat sheet on gitlab.
  - Use the git cheat sheet on gitlab.
 


